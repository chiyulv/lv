create procedure 插入仓库管理员信息
@AID char(18),@Wkeeper char(7),@Asex char(1),@Wkphone nchar(10),@Wpassword nchar(20)
as
INSERT into Admin
values
(@AID,@Wkeeper,@Asex,@Wkphone,@Wpassword)
go

