create procedure 插入水果信息
@Fno nchar(10),@Fvariety nchar(10),@Fname nchar(10),@Fprice money,@Fintroduction nvarchar(2000),@Fstate nchar(3),@Wno char(3),@Wtime date,@Fquantity int
as
INSERT into Fruit
values
(@Fno,@Fvariety,@Fname,@Fprice,@Fintroduction,@Fstate,@Wno,@Wtime,@Fquantity)
go

