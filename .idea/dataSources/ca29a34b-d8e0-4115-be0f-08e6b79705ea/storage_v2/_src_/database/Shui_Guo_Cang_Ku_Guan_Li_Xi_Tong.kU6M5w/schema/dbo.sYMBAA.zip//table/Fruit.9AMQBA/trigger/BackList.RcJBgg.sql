create trigger BackList
on Fruit for delete
as
begin
delete from List
where Fno not in (select Fno from Fruit deleted)
end
go

